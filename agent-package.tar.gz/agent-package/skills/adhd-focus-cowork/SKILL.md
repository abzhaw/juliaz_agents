---
name: adhd-focus
description: >
  ALWAYS trigger this skill at the very start of any new session, task, or when multiple new agents and skills are being set up together in the juliaz_agents ecosystem. This is the mandatory planning and problem-understanding ritual for everything that happens in juliaz_agents. Trigger when: a new agent is being created, a cluster of skills is being assembled, a new feature or system is being designed, Raphael asks "what should we do" or "where do we start", or whenever the conversation involves Julia, Antigravity, OpenClaw, or any component of the multi-agent system. The goal: always understand the big picture before touching any code or config. Do not skip this even for tasks that feel small — small tasks often carry big consequences in a multi-agent system.
---

# ADHD Focus — Problem Understanding & Silver Lining

> "Before we build, we understand. Before we understand, we zoom out."

This skill enforces structured problem clarity in the juliaz_agents ecosystem. It exists because multi-agent systems accumulate complexity fast — and without a shared "silver lining" (a guiding thread), individual agents and tasks drift.

---

## When this skill activates

Whenever work begins in juliaz_agents — whether that's a new agent, a cluster of skills, a debugging session, or a new feature — this ritual runs first. It's not overhead; it's the immune system of the project.

---

## Step 1 — Zoom Out: What Is the Real Goal?

Before anything else, answer the **Big Picture Question**:

> *"If this task succeeds completely, what does that enable or unlock?"*

Ask this even if the request seems concrete. A request like "add a new skill to Julia" is not really about the skill — it's about making Julia smarter, more autonomous, or more useful to Raphael. Surface that.

**Techniques to use (pick whichever fits):**

- **5 Whys** — Ask "why does this matter?" five times in succession. Stop when you hit a value (speed, autonomy, reliability, creativity, etc.).
- **First Principles** — Strip away assumptions. What is the minimum true thing we're trying to achieve?
- **Outcome Mapping** — State: "When this is done, Raphael will be able to _____. Julia will be able to _____."

Read `references/problem_methods.md` for detailed templates if you need them.

---

## Step 2 — Map the Problem Space

Once the big picture is clear, map what we're actually dealing with:

1. **What do we know for certain?** (facts, constraints, existing code/agents)
2. **What are we assuming?** (list assumptions explicitly — they bite later)
3. **What are the unknowns?** (things we'll need to discover or decide)
4. **What could go wrong?** (failure modes specific to multi-agent systems: broken bridges, silent failures, context loss between agents)
5. **What does Julia need to know or do to support this?** (consider the full agent stack: Antigravity → Julia → OpenClaw → any sub-agents)

Keep this short. This is a map, not an essay.

---

## Step 3 — Write the Silver Lining

The Silver Lining is a single sentence that captures the soul of what we're doing. It's what every decision in this session gets measured against.

**Format:**
> *"We are [doing X] so that [Julia/Raphael] can [achieve Y], which matters because [Z]."*

**Examples:**
> "We are building the adhd_focus skill so that every session in juliaz_agents starts with shared clarity, which matters because lost context is the #1 cause of wasted work in multi-agent systems."

> "We are refactoring the bridge health check so that Julia can self-diagnose connectivity issues, which matters because Raphael shouldn't have to babysit inter-agent communication."

Save the Silver Lining prominently — include it in any documents or plans generated this session.

---

## Step 4 — Draft the Plan

With the silver lining in place, create a concrete plan. Use this structure:

```
## Session Plan — [Date] — [Short Title]

**Silver Lining:** [one sentence from Step 3]

**Scope:** [what is IN scope / what is explicitly OUT of scope]

**Steps:**
1. [First concrete action]
2. [Second concrete action]
...

**Julia's Role:** [how the multi-agent system (Julia, OpenClaw, sub-agents) is involved]

**Done When:** [clear, testable definition of done]

**Risks:** [top 1-3 risks and how we'll handle them]
```

Read `references/plan_template.md` for the full template with examples.

---

## Step 5 — Sync with Julia (when applicable)

If this session involves the Julia multi-agent system:

1. Check whether Julia's bridge is healthy before assuming connectivity:
   - Look for `mcporter call julia-bridge.bridge_health` results or equivalent health signals
   - If bridge is down, note it in the plan and either fix it first or work around it
2. Identify which Julia sub-agents are relevant (julia_medium_agent, openclaw, orchestrator, etc.)
3. Note what context Julia will need — multi-agent systems lose context at boundaries, so be explicit about what gets passed
4. If deploying new skills to Julia's ecosystem, confirm the skill location and triggering conditions are correct before writing any code

---

## Outputs

By the end of this skill, the session should have:

- [ ] A clear **Big Picture statement** (one paragraph max)
- [ ] A written **Silver Lining** (one sentence)
- [ ] A **Session Plan** with scope, steps, and done-when
- [ ] Julia sync notes (if applicable)

These don't need to be formal documents unless Raphael asks. They can live in the conversation. But they must exist before execution begins.

---

## Mindset Notes

This skill exists because:

- **Multi-agent systems punish vague intent.** When multiple agents act on an unclear goal, they diverge. A five-minute planning step prevents hours of cleanup.
- **ADHD-friendly structure isn't about rigidity.** It's about giving the brain a hook — a single clear thread to return to when things get complex. The Silver Lining is that hook.
- **The big picture prevents local optimization traps.** Without it, it's easy to build something technically correct that solves the wrong problem.

If a task feels too small to warrant this ritual, ask: *"Could this interact with Julia or other agents in unexpected ways?"* If yes, run the ritual anyway.

---

## Reference Files

- `references/problem_methods.md` — Detailed templates for 5-Whys, First Principles, Outcome Mapping
- `references/plan_template.md` — Full session plan template with filled examples
