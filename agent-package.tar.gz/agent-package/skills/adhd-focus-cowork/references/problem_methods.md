# Problem Understanding Methods

Reference templates for Step 1 and Step 2 of the adhd_focus skill.

---

## Method 1: 5 Whys

Ask "why does this matter?" five times. Stop when you reach a value or a constraint that can't be further decomposed.

**Template:**
```
Request: [what was asked]

Why 1: Why do we want this?
  → [answer]

Why 2: Why does that matter?
  → [answer]

Why 3: Why is that important?
  → [answer]

Why 4: Why is that the goal?
  → [answer]

Why 5: Why is that worth doing?
  → [core value: speed / reliability / autonomy / creativity / trust / ...]

Root insight: [1 sentence summarizing what you found]
```

**Example:**
```
Request: "Add a heartbeat check to the Julia bridge"

Why 1: Why do we want a heartbeat check?
  → So we know if the bridge is alive

Why 2: Why does that matter?
  → Because agents fail silently when the bridge is down

Why 3: Why is silent failure a problem?
  → Because Raphael only finds out when something important doesn't happen

Why 4: Why is late discovery bad?
  → Because debugging after the fact costs hours

Why 5: Why does that cost matter?
  → Because Julia's value is reliable autonomous action — broken trust destroys that value

Root insight: This is about system reliability and trust, not just monitoring.
```

---

## Method 2: First Principles

Strip away all assumptions until you're left with what's fundamentally true.

**Template:**
```
Conventional framing: [how people usually describe this problem]

Assumptions hidden in that framing:
  - [assumption 1]
  - [assumption 2]
  - [assumption 3]

What's actually true / unavoidable:
  - [fundamental fact 1]
  - [fundamental fact 2]

What does that tell us we should do differently?
  → [insight]
```

**Example:**
```
Conventional framing: "We need to write better documentation for Julia's agents"

Assumptions hidden:
  - That agents read documentation (they don't — they read prompts and SKILL.md files)
  - That more text = more clarity
  - That documentation is separate from code/config

What's actually true:
  - Agents act on what's in their context window
  - The "documentation" IS the SKILL.md and SOUL.md files
  - Clarity comes from structure, not volume

Insight: Don't write docs — improve the SKILL.md files directly. They're not docs, they're the agent's operating instructions.
```

---

## Method 3: Outcome Mapping

Start from the end state and work backward.

**Template:**
```
When this is fully done:

Raphael will be able to:
  - [capability 1]
  - [capability 2]

Julia will be able to:
  - [capability 1]
  - [capability 2]

The system will no longer need to:
  - [eliminated pain 1]
  - [eliminated pain 2]

Working backward from that — the first thing that needs to exist is:
  → [first dependency]

And before that:
  → [prerequisite]
```

---

## Problem Space Map (Step 2)

Use this for any task before writing a plan:

```
## Problem Space: [short title]

KNOWNS (things we're certain about):
  -
  -

ASSUMPTIONS (things we're treating as true but haven't confirmed):
  -
  -

UNKNOWNS (things we need to discover or decide):
  -
  -

FAILURE MODES (what could go wrong, especially in multi-agent context):
  - Silent failures:
  - Context loss between agents:
  - Drift (agents working toward different goals):
  - Scope creep:

JULIA IMPLICATIONS (what the multi-agent stack needs to know/do):
  -
```
