# Session Plan Template

Use this template for every session in juliaz_agents. Fill it in during Steps 3–5 of the adhd_focus ritual.

---

## Session Plan Template (copy this)

```markdown
## Session Plan — [YYYY-MM-DD] — [Short Title]

**Silver Lining:** [one sentence: "We are X so that Y can Z, which matters because W"]

**Context:** [1-2 sentences on what brought us here — what was the trigger?]

---

### Scope

IN scope:
- [specific thing 1]
- [specific thing 2]

OUT of scope (explicitly):
- [thing we're NOT doing today even if tempting]
- [thing that belongs to a different session]

---

### Steps

1. [First concrete action — specific enough to be tickable]
2. [Second action]
3. [Third action]
...

---

### Julia's Role

Agents involved:
- [ ] Julia (orchestrator) — [what it needs to do or know]
- [ ] OpenClaw — [if applicable]
- [ ] julia_medium_agent — [if applicable]
- [ ] [other sub-agent] — [if applicable]

Bridge health: [ ] checked / [ ] not needed this session

Context handoff notes:
[What does Julia need to know that it won't have in its context by default?]

---

### Done When

This session is complete when:
- [ ] [verifiable condition 1]
- [ ] [verifiable condition 2]
- [ ] [verifiable condition 3]

---

### Risks

| Risk | Likelihood | Mitigation |
|------|-----------|------------|
| [risk 1] | low/med/high | [how we handle it] |
| [risk 2] | low/med/high | [how we handle it] |

---

### Notes / Decisions Made

[Any decisions made during planning that future-us should know about]
```

---

## Filled Example: New Agent Setup

```markdown
## Session Plan — 2026-02-22 — Add adhd_focus Skill

**Silver Lining:** We are creating the adhd_focus skill so that every juliaz_agents session starts with structured clarity, which matters because multi-agent systems collapse into chaos without shared intent.

**Context:** Raphael asked for a planning skill that activates automatically when new agents or skills are being set up, to ensure the big picture is never lost.

---

### Scope

IN scope:
- Write SKILL.md for adhd_focus with 5-step ritual
- Write reference files (problem_methods.md, plan_template.md)
- Package and make available to .claude/skills/

OUT of scope:
- Running evals/benchmarks (this is v1, iterate based on use)
- Integrating with Julia's orchestrator (future session)

---

### Steps

1. Read skill-creator SKILL.md to understand structure requirements
2. Explore juliaz_agents to understand Julia's architecture and agent naming
3. Write adhd_focus/SKILL.md with the 5-step ritual
4. Write reference files for problem methods and plan template
5. Package the skill

---

### Julia's Role

Agents involved:
- [ ] None directly — this is a planning meta-skill

Bridge health: [ ] not needed this session

Context handoff notes: N/A

---

### Done When

- [ ] SKILL.md exists and follows skill-creator structure
- [ ] Reference files provide actionable templates
- [ ] Skill is available in .claude/skills/ and auto-triggers correctly

---

### Risks

| Risk | Likelihood | Mitigation |
|------|-----------|------------|
| Skill is too prescriptive and feels like overhead | medium | Keep it lightweight — outputs can live in conversation, not files |
| Trigger description too vague (under-triggers) | medium | Make description explicit and pushy per skill-creator guidance |

---

### Notes / Decisions Made

- Named "adhd_focus" to honor the ADHD-friendly structure framing Raphael mentioned
- Silver Lining format chosen because single-sentence clarity works better than multi-point summaries for staying on track
```
