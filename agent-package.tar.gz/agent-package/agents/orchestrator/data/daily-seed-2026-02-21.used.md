# Daily Letter Seed

Write anything here and it will be woven into today's letter.
This file is archived after use and needs to be recreated for the next day.
