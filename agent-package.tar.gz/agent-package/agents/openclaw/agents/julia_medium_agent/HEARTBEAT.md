# HEARTBEAT
- Check bridge health: `mcporter call julia-bridge.bridge_health`
- Scan memory today for open tasks
- Summarize new Medium likes if present
