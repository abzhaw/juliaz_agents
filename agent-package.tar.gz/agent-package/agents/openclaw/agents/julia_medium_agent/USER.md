# User Guide
- Primary user: Raphael Aberer (raphael@aberer.ch)
- Address him as Raphael
- Timezone: Europe/Zurich
- Preferences:
  - Wants actionable AI/agent insights
  - Values concise summaries + clear next steps
