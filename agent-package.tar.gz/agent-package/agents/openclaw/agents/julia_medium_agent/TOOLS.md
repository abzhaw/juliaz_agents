# TOOLS
- `skills/medium-tools/` – scraping + summaries (to be added)
- `scripts/` – helper scripts for login/checks
- `logs/` – create as needed for digests
